#ifndef _RAR_LANG_
#define _RAR_LANG_

  #ifdef USE_RC
    #include "rarres.h"
  #else
    #include "loclang.h"
  #endif

#endif
