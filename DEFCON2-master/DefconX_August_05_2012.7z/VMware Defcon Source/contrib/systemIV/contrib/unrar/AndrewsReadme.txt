Files to leave out of rar project:

arccmt.cpp
coder.cpp
log.cpp
model.cpp
unpack15.cpp
unpack20.cpp
win32acl.cpp
win32stm.cpp
