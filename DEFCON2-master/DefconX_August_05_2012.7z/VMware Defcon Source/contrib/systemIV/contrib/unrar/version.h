#define RARVER_MAJOR     3
#define RARVER_MINOR    30
#define RARVER_BETA      1
#define RARVER_DAY      14
#define RARVER_MONTH    11
#define RARVER_YEAR   2003
