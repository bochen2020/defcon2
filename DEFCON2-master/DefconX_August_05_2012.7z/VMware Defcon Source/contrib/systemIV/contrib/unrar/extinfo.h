#ifndef _RAR_EXTINFO_
#define _RAR_EXTINFO_


void SetExtraInfo(CommandData *Cmd,Archive &Arc,char *Name,wchar *NameW);
void SetExtraInfoNew(CommandData *Cmd,Archive &Arc,char *Name,wchar *NameW);

#endif
